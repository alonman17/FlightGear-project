
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
    <h1> Flight Gear Project</h1>
    <div>
      <ul>
          <li>Daniel Ohayon </li>
          <li>Alon Manshari </li>
          <li>Rom Bardugo </li>
          <li>Shon Hazan </li>
          <li>Jony Singer </li>
      </ul>
      </div>
    </header>
    </div>
  );
}

export default App;
