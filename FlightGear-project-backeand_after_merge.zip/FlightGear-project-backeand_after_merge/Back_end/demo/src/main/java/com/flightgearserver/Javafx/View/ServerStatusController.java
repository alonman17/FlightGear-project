package flightgearserver.Javafx.View;

public class ServerStatusController {
}
