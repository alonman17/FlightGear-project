package tirgul.view;

public interface Icli {
    public void shoutdown();

    public void reset();

    public void print_stream();

    public void setAileron(float n);

    public void setRudder(float n);

    public void setElevator(float n);

    public void setThruttle(String n);
}
