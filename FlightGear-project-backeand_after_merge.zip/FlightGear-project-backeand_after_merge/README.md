# FlightGear-project
In this project we will manage flight gear simulation. 
# Agent :
  * Language : JAVA .
# Back-End :
  * Language : JAVA .
  * frameWork: SpringBoot .
# Front_end :
  * Language : Js .
  * Library : React . 
  
   
